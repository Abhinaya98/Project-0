package com.bloodbank.app.service;

import java.util.List;

import com.bloodbank.app.model.BloodBankCenter;

public interface BloodBankService {

	public List<BloodBankCenter> getAllBloodBankCenters();

	public BloodBankCenter getBloodBankCenterbyId(int id);

	public void addBloodBankCenter(BloodBankCenter bloodBankCenter);

	public void deleteBloodBankCenter(int centerId);

	public BloodBankCenter updateBloodBankCenter(String Centername, int centerId);
	
	
	

}
