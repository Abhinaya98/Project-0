package com.bloodbank.app.controller;

import java.util.List;

import org.apache.log4j.Logger;

import com.bloodbank.app.model.BloodBankCenter;
import com.bloodbank.app.service.BloodBankService;
import com.bloodbank.app.service.BloodBankServiceImplementation;

public class BloodBankController {
	static Logger log = Logger.getLogger("BloodBankController.class");
	
	
		BloodBankService bloodBankServiceImplementation = new BloodBankServiceImplementation();
		
		      
			 public  void addBloodBankCenter(BloodBankCenter bloodBankCenter ) { //DTO
			   log.info("addBloodBankCenter method of controller");
			  try {
				bloodBankServiceImplementation.addBloodBankCenter(bloodBankCenter);
			} catch (Exception e) {
				e.printStackTrace();
			}
		   }
			 
			 public List<BloodBankCenter> getAllBloodBankCenters(){
				 log.info("getAllBloodBankCenter method of controller");
					return bloodBankServiceImplementation.getAllBloodBankCenters();
				}
				public BloodBankCenter getBloodBankCentersbyId(int id) {
					return bloodBankServiceImplementation.getBloodBankCenterbyId(id);
				}
		


			public void deleteBloodBankCenter(int centerId) {
				 log.info("deleteBloodBankCenter method of controller");
				
				try {
					bloodBankServiceImplementation.deleteBloodBankCenter(centerId);
				} catch (Exception e) {
				
					e.printStackTrace();
				}
			}

			public BloodBankCenter upadateBloodBankCenter( String name,int centerId) {
				 log.info("updateBloodBankCenter method of controller");
				return bloodBankServiceImplementation.updateBloodBankCenter(name,centerId);
				
			}

}
