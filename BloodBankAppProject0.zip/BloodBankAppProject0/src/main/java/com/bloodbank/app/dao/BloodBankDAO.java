package com.bloodbank.app.dao;

import java.util.List;

import com.bloodbank.app.model.BloodBankCenter;

public interface BloodBankDAO {
	
	public List<BloodBankCenter> getAllBloodBankCenters();

	public BloodBankCenter getBloodBankCenterbyId(int id);

	public void addBloodBankCenter(BloodBankCenter bloodBankCenter);

	public void deleteBloodBankCenter(int centerId);

	public BloodBankCenter updateBloodBankCenter(String Centername, int centerId);
	

}
