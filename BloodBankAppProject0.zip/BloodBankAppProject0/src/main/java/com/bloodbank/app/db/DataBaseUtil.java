package com.bloodbank.app.db;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DataBaseUtil {
	 
	static Logger log=Logger.getLogger(DataBaseUtil.class);

public static  Connection getConnection()  throws Exception{
	
	log.info("DataBaseUtil is used");
		
		FileInputStream fileStream = new FileInputStream("jdbc.properties"); //io
		Properties properties = new Properties(); //resource bundle 
		properties.load(fileStream);
		String url = properties.getProperty("url");	
		String id = properties.getProperty("id"); 
		String pwd = properties.getProperty("password"); 
	
		  Connection con = DriverManager.getConnection(url,id,pwd); 

	            
	            return con;
	}

}
