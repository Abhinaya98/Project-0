package com.bloodbank.app.BloodBankAppProject0;

import java.util.Scanner;


import org.apache.log4j.Logger;


import com.bloodbank.app.controller.BloodBankController;
import com.bloodbank.app.model.BloodBankCenter;

public class BloodBankApp {
 	static Logger log=Logger.getLogger("BloodBankApp.class");
 

public static void main(String[] args) {

	    
		Scanner sc=new Scanner(System.in);
		
		System.out.println("====BloodBank Application===========");
		log.info("Taking user choice");
		
		BloodBankController controller=new BloodBankController();
		BloodBankCenter bloodBankCenter=new  BloodBankCenter();
		System.out.println("1.insert  boold bank details");
		System.out.println("2.enter center id to get details of particular BloodBankCentre");
		System.out.println("3.display all available BloodBankcentres");
		 System.out.println("4.delete a bloodbankcentre details");
			System.out.println("5.update bloodbankcenter details ");
			int ch;
		do {
			System.out.println("enter your choice");
			ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			log.info("user asking for insert oepration");
		System.out.println("enter boold bank details");

		System.out.println("enter centerid");
       int centerId=sc.nextInt();sc.nextLine();
       log.info("user entered centerId");
		System.out.println("enter centername");
		 String centerName=sc.nextLine();
		 log.info("user entered centerName");
		 System.out.println("street");
		 String street=sc.nextLine();
		 log.info("user entered street");
		 System.out.println("enter city");
		 String city=sc.nextLine();
		 log.info("user entered city");
		 System.out.println("enter state");
		 String state=sc.nextLine();
		 log.info("user entered state");
		 System.out.println("enter pincode");
		 String pincode=sc.nextLine();
		 log.info("user entered pincode");
		 bloodBankCenter.setCenterId(centerId);
		 bloodBankCenter.setCenterName(centerName);
		 bloodBankCenter.setStreet(street);
		 bloodBankCenter.setCity(city);
		 bloodBankCenter.setState(state);
		 bloodBankCenter.setPincode(pincode);
		 log.info("calling addBloodBankCenter method of controller");
		 
		 controller.addBloodBankCenter(bloodBankCenter);
		 
		 System.out.println(" Use case 1- Adding Blood bank ceneter is completed.");
		 break;
		case 2:
		{
		 
			System.out.println("enter center id to get details of particular BloodBankCentre");
		 int centerId1=sc.nextInt();
		 log.info("fetching all the available BloodBankCenters with specific centerid");

		 System.out.println(controller.getBloodBankCentersbyId(centerId1));
			break;
		}
		case 3:
		{
			System.out.println("====display all available BloodBankcentres===");
			log.info("fetching all the available BloodBankCenters ");
		 System.out.println(controller.getAllBloodBankCenters());
		 
		 
		 break;
		}
		case 4:
		{
			log.info("user asking for delete oepration");
		 System.out.println("delete a bloodbankcentre details");
		 System.out.println("enter centerId of bloodbankcenter which is to be deleted");
		 int CenterId=sc.nextInt();
		log.info("calling deleteBloodBankCenter method of controller");
		controller.deleteBloodBankCenter(CenterId);
		System.out.println("bloodbankcenter with "+CenterId+" got deleted");
		break;
		}
		case 5:
		{
			log.info("user asking for update oepration");
			System.out.println("update bloodbankcenter details ");
			
			System.out.println("enter centerId of bloodbankcenter which is to be updated");
			int CenterId=sc.nextInt();
			sc.nextLine();
			System.out.println("enter centername of bloodbankcenter which is to be updated");
			String name=sc.nextLine();
			log.info("calling updateBloodBankCenter method of controller");
			System.out.println("updated....");
			controller.upadateBloodBankCenter(name,CenterId);
			break;
		}
			
		case 0:
		{
			System.out.println("you have Loggged out of the application");
			break;
		}
		}
		
	}while(ch!=0);
}
}



