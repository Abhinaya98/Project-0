package com.bloodbank.app.service;

import java.util.List;

import org.apache.log4j.Logger;

import com.bloodbank.app.model.BloodBankCenter;
import com.bloodbank.app.dao.*;
import com.bloodbank.app.db.DataBaseUtil;

public class BloodBankServiceImplementation implements BloodBankService{
	 static Logger log=Logger.getLogger(DataBaseUtil.class);

	BloodBankDAOImplementation bloodBankDaoImplementation=new BloodBankDAOImplementation();
   
	@Override
	public List<BloodBankCenter> getAllBloodBankCenters() {
      log.info("getAllBloodCenters method of Service method is called");
		return bloodBankDaoImplementation.getAllBloodBankCenters();
	}

	@Override
	public BloodBankCenter getBloodBankCenterbyId(int id) {
		 log.info("getBloodCenterbyId method of Service method is called");
		return bloodBankDaoImplementation.getBloodBankCenterbyId(id);
	}

	@Override
	public void addBloodBankCenter(BloodBankCenter bloodBankCenter) {
		 log.info("addBloodCenter method of Service method is called");
		try {
			bloodBankDaoImplementation.addBloodBankCenter(bloodBankCenter);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteBloodBankCenter(int centerId) {
		 log.info("deleteBloodCenters method of Service method is called");
		try {
			bloodBankDaoImplementation.deleteBloodBankCenter(centerId);
		} catch (Exception e) {
			
			e.printStackTrace();
		}

		
	}

	@Override
	public BloodBankCenter updateBloodBankCenter(String name, int centerId) {
		 log.info("updateBloodCenter method of Service method is called");
		return bloodBankDaoImplementation.updateBloodBankCenter(name,centerId);
	}

}
