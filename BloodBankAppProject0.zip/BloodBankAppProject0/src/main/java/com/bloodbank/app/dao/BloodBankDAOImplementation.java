package com.bloodbank.app.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

import com.bloodbank.app.model.BloodBankCenter;
import com.bloodbank.app.db.DataBaseUtil;

public class BloodBankDAOImplementation implements BloodBankDAO {
static Logger log=Logger.getLogger(BloodBankDAOImplementation.class);

	@Override
	public List<BloodBankCenter> getAllBloodBankCenters() {
		
		 log.info("getAllBloodBankCenter method of DAO");
		 
		List<BloodBankCenter> list=new ArrayList<BloodBankCenter>();
		try {
			Connection con=DataBaseUtil.getConnection();
			Statement pst=con.createStatement();
			ResultSet rs=pst.executeQuery("select * from BloodBankCenter");
			
			while(rs.next()) {
				BloodBankCenter b=new BloodBankCenter();
				b.setCenterId(rs.getInt(1));
				b.setCenterName(rs.getString(2));
				b.setState(rs.getString(3));
				b.setStreet(rs.getString(4));
				b.setCity(rs.getString(5));
				b.setPincode(rs.getString(6));
				list.add(b);
			
			}
			
		
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return list;
		
	}
	@Override
	public BloodBankCenter getBloodBankCenterbyId(int id) {
		 log.info("getBloodBankCenterbyId method of DAO");
		BloodBankCenter b=new BloodBankCenter();
		try {
			Connection con=DataBaseUtil.getConnection();
			PreparedStatement pst=con.prepareStatement("select * from BloodBankCenter where centerId=?");
			pst.setInt(1,id);
			
			ResultSet rs=pst.executeQuery();
			
			while(rs.next()) {
				
				b.setCenterId(rs.getInt(1));
				b.setCenterName(rs.getString(2));
				b.setState(rs.getString(3));
				b.setStreet(rs.getString(4));
				b.setCity(rs.getString(5));
				b.setPincode(rs.getString(6));
				
			}
			
		
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return b;
			
	
	}
	

	@Override
	public void addBloodBankCenter(BloodBankCenter bloodBankCenter) {
		
		log.info("addBloodBankCenter method of DAO is called");
		
		try {
			Connection con=DataBaseUtil.getConnection();
			PreparedStatement pst=con.prepareStatement("insert into BloodBankCenter values(?,?,?,?,?,?)");
			pst.setInt(1, bloodBankCenter.getCenterId());
			pst.setString(2, bloodBankCenter.getCenterName());
			pst.setString(3, bloodBankCenter.getStreet());
			pst.setString(4, bloodBankCenter.getCity());
			pst.setString(5, bloodBankCenter.getState());
			pst.setString(6, bloodBankCenter.getPincode());
			pst.executeUpdate();
		
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void deleteBloodBankCenter(int centerId) {
		
		log.info("deleteBloodBankCenter method of DAO");
		
		BloodBankCenter b=new BloodBankCenter();
		try {
			Connection con=DataBaseUtil.getConnection();
			PreparedStatement pst=con.prepareStatement("delete  from BloodBankCenter where centerId=?");
			pst.setInt(1,centerId);
			int r=pst.executeUpdate();
			
			log.info("record deleted successfully");
				
			}
			
		
			
		 catch (Exception e) {
			
			e.printStackTrace();
		}

		
	}

	@Override
	public BloodBankCenter updateBloodBankCenter(String Centername, int centerId) {
		
		log.info("updateBloodBankCenter method of DAO");
		
		BloodBankCenter b=new BloodBankCenter();
		try {
			Connection con=DataBaseUtil.getConnection();
			String query="update BloodBankCenter set CenterName=? where CenterId=?"; 
			
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, Centername);
			pst.setInt(2,centerId);
		int c=pst.executeUpdate();
		
		//log.info("record updated successfully");
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return b;
		
	}

}
