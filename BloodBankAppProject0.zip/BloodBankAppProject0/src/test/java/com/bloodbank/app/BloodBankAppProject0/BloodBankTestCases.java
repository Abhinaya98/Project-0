package com.bloodbank.app.BloodBankAppProject0;



	import static org.junit.Assert.*;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.util.ArrayList;
	import java.util.List;

	import org.junit.Test;

import com.bloodbank.app.dao.BloodBankDAOImplementation;
import com.bloodbank.app.db.DataBaseUtil;
import com.bloodbank.app.model.BloodBankCenter;

	public class BloodBankTestCases {


		@Test
		public void testGetBloodBankCentersbyId() {
			boolean flag1=false;
			List<BloodBankCenter> list=new ArrayList<BloodBankCenter>();
			try {
				Connection con=DataBaseUtil.getConnection();
				Statement pst=con.createStatement();
				ResultSet rs=pst.executeQuery("select * from BloodBankCenter where CenterId=1");
				
				if(rs.next())
					flag1=true;
					} 
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
			assertTrue(flag1);
			
		}
		@Test
		public void testaddBloodBankCenter() {
			boolean flag2=false;
			
			try {
				Connection con=DataBaseUtil.getConnection();
				Statement pst=con.createStatement();
				int rs=pst.executeUpdate("insert into BloodBankCenter values(45,'wv','kjklkoojkh','vanmppllla','pradgnkkgesh','20766901')");
				BloodBankDAOImplementation dao=new BloodBankDAOImplementation();
				BloodBankCenter b=new BloodBankCenter();
				dao.addBloodBankCenter(b);
				PreparedStatement ps=con.prepareStatement("select *from BloodBankCenter where CenterId=45");
				ResultSet rs2=ps.executeQuery();
				if(rs2.next()) 
					flag2=true;
					} 
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
			assertTrue(flag2);
			
		}
		
		
		@Test
		public void testupdateBloodBankCenter() {
			boolean flag4=false;
			
			try {
				Connection con=DataBaseUtil.getConnection();
				Statement t=con.createStatement();
				int s=t.executeUpdate("update  BloodBankCenter set CenterName='mn' where CenterId=8");
				BloodBankDAOImplementation dao2=new BloodBankDAOImplementation();
				dao2.updateBloodBankCenter("mn", 8);
				PreparedStatement ps1=con.prepareStatement("select *from BloodBankCenter where CenterName='mn'");
				ResultSet rs1=ps1.executeQuery();
				if(rs1.next()) 
					flag4=true;
					} 
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
			assertTrue(flag4);
			
		}
		
		
		public void testdeleteBloodBankCenter(){
			int count=0,count1=0;
			try{
				Connection con=DataBaseUtil.getConnection();
				Statement ps=con.createStatement();
				ResultSet  rs4=ps.executeQuery("select * from BloodBankCenter");
				while(rs4.next()){
					count++;
				}
				BloodBankDAOImplementation daodel=new BloodBankDAOImplementation();
				daodel.deleteBloodBankCenter(4);
				ResultSet rs6=ps.executeQuery("select * from BloodBankCenter");
				
				while(rs6.next()){
					count1++;
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
			System.out.println(count);
			System.out.println(count1);
			assertNotEquals(count, count1);
		}

		@Test
		public void testGetAllBloodBankCenters() {
			
			boolean flag=false;
			List<BloodBankCenter> list=new ArrayList<BloodBankCenter>();
			try {
				Connection con=DataBaseUtil.getConnection();
				Statement pst=con.createStatement();
				ResultSet rs=pst.executeQuery("select * from BloodBankCenter");
				
				if(rs.next())
					flag=true;
					} 
			catch (Exception e) {
				
				e.printStackTrace();
			}
			
			assertTrue(flag);
		}

		


	}



